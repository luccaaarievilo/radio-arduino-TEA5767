/*
  =====================================================================
  RADIO FM - ARDUINO UNO + TEA5767 + ENCODER ROTATIVO  (SEM TELA)
  =====================================================================

  COMPONENTES:
    - Arduino Uno
    - Modulo FM TEA5767 (I2C, endereco 0x60)
    - Encoder rotativo com botao (CLK, DT, SW)
    - Sem tela: todo o feedback e' mostrado no Serial Monitor (9600 baud)

  LIGACAO (Arduino Uno):

    TEA5767:
      VCC  -> 5V  (ou 3.3V, conforme o modulo)
      GND  -> GND
      SDA  -> A4
      SCL  -> A5

    ENCODER ROTATIVO:
      CLK (A)    -> D2
      DT  (B)    -> D3
      SW  (botao)-> D4
      VCC        -> 5V
      GND        -> GND

    AUDIO:
      O som sai pelos pinos de saida de audio do proprio modulo TEA5767
      (speaker / amplificador / fone, conforme o modulo).

  CONTROLES (mesma logica dos botoes, sem a tela):
    - Girar para frente  -> aumenta a frequencia (passo FREQ_STEP)
    - Girar para tras    -> diminui a frequencia (passo FREQ_STEP)
    - 1 clique no botao  -> busca a estacao mais proxima ANTERIOR
    - 2 cliques no botao -> busca a estacao mais proxima POSTERIOR
    - 3 cliques no botao -> liga / desliga o mudo

  ANTI-RUIDO (para sintonizar sem estatico):
    - Soft mute (SMUTE) ativo no chip: quando nao ha estacao, o som e
      cortado quase por completo, entao o ruido de fundo some.
    - Ao girar o encoder a saida fica silenciada; pare de girar e o som
      volta sozinho apos ~400 ms (facilita "cacar" a estacao).
    - A busca por botao tambem e feita em silencio.

  OBSERVAÇÕES:
    - A frequencia fica salva em EEPROM e e' restaurada ao ligar.
    - Abra o Serial Monitor em 9600 baud para ver frequencia, nivel de
      sinal, estereo/mono e mudo em tempo real.
    - Se o sentido de giro do encoder estiver trocado, mude ENCODER_INVERT
      para 1 (veja abaixo).
  =====================================================================
*/

#include <Wire.h>
#include <EEPROM.h>

// ============================ PINAGEM (Arduino Uno) ===================
#define TEA5767_ADDR 0x60

#define ENCODER_CLK 2
#define ENCODER_DT  3
#define ENCODER_SW  4

// ============================ CONFIGURACAO ============================
#define FREQ_STEP  0.1f    // passo de sintonia (MHz) por clicada do encoder
#define FREQ_MIN10 875     //  87.5 MHz  (em unidades de 0.1 MHz)
#define FREQ_MAX10 1080    // 108.0 MHz  (em unidades de 0.1 MHz)
#define FREQ_DEF10 1019    // 101.9 MHz  (padrao)

#define BTN_DEBOUNCE_MS 30
#define MULTI_CLICK_WINDOW_MS 400
#define ENCODER_ISR_DEBOUNCE_US 200

#define ENCODER_INVERT 0   // 0 = normal | 1 = inverte o sentido do giro
#define TUNING_UNMUTE_DELAY_MS 400  // parado neste tempo, o som volta

#define EEPROM_FREQ_ADDR 0

// ======================= STRUCT (antes de qualquer funcao) ===========
struct MultiClickButton {
  uint8_t pin;
  bool lastReading;
  bool stableState;
  unsigned long lastDebounceTime;
  uint8_t clickCount;
  unsigned long firstClickTime;
};

// ======================= ESTADO DO RADIO ===============================
float   currentFreq = FREQ_DEF10 / 10.0f;
bool    isMuted     = false;
bool    isStereo    = false;
uint8_t signalLevel = 0;

unsigned long lastStatusPoll = 0;
const unsigned long STATUS_POLL_INTERVAL = 700;

MultiClickButton encoderBtn = { ENCODER_SW, HIGH, HIGH, 0, 0, 0 };

volatile unsigned long lastStepTime = 0;
bool    tuningMuted = false;   // saida silenciada enquanto gira o encoder

// ======================================================================
//                         TEA5767 - BAIXO NIVEL (I2C)
// ======================================================================
// PLL = 4 * (f + 225 kHz) / 32.768 kHz   (modulos com cristal de 32.768 kHz)
uint32_t calcPLL(float freqMHz) {
  double freqHz = (double)freqMHz * 1000000.0;
  uint32_t pll = (uint32_t)((4.0 * (freqHz + 225000.0)) / 32768.0 + 0.5);
  return pll;
}

float pllToFreq(uint32_t pll) {
  double freqHz = ((double)pll * 32768.0 / 4.0) - 225000.0;
  return (float)(freqHz / 1000000.0);
}

// Escreve os 5 bytes de configuracao do TEA5767 (formato fixo do chip).
void tea5767_write(float freqMHz, bool muteFlag, bool searchMode, bool searchUp) {
  uint32_t pll = calcPLL(freqMHz);
  uint8_t data[5];

  // Byte 1: MUTE(7) | SM(6) | PLL[13:8](5:0)
  data[0] = (muteFlag   ? 0x80 : 0x00) |
            (searchMode ? 0x40 : 0x00) |
            ((pll >> 8) & 0x3F);

  // Byte 2: PLL[7:0]
  data[1] = (uint8_t)pll;

  // Byte 3: SUD(7) | SSL[1:0](6:5) | HLSI(4) | MS(3) | MR(2) | ML(1) | SWP1(0)
  uint8_t sud  = searchUp ? 1 : 0;
  uint8_t ssl1 = 1, ssl0 = 0;   // limiar de busca "mid"
  uint8_t hlsi = 1;             // injecao em banda lateral alta
  data[2] = (sud << 7) | (ssl1 << 6) | (ssl0 << 5) | (hlsi << 4);

  // Byte 4: SWP2(7) | STBY(6) | BL(5) | XTAL(4) | SMUTE(3) | HCC(2) | SNC(1) | SI(0)
  uint8_t stby  = 0;
  uint8_t bandL = 0;
  uint8_t xtal  = 1;   // PLLREF=0 e XTAL=1 -> cristal de 32.768 kHz
  uint8_t smute = 1;   // soft mute: chip corta o estatico quando nao ha estacao
  uint8_t hcc   = 1;
  uint8_t snc   = 1;
  data[3] = (stby << 6) | (bandL << 5) | (xtal << 4) |
            (smute << 3) | (hcc << 2) | (snc << 1);

  // Byte 5: PLLREF(7)=0 | DTC(6) | ...
  uint8_t dtc = 1;   // 1 = de-emfase 75 us (BR/Americas) | 0 = 50 us (Europa)
  data[4] = (dtc << 6);

  Wire.beginTransmission(TEA5767_ADDR);
  Wire.write(data, 5);
  Wire.endTransmission();
}

// Le os 5 bytes de status do TEA5767.
bool tea5767_readStatus(bool &ready, bool &bandLimit, bool &stereoOut,
                        uint8_t &level, float &freqOut) {
  uint8_t b[5];
  uint8_t n = Wire.requestFrom((int)TEA5767_ADDR, 5);
  if (n < 5) return false;
  for (int i = 0; i < 5; i++) b[i] = Wire.read();

  ready     = (b[0] & 0x80) != 0;   // RF  - estacao achada / limite de banda
  bandLimit = (b[0] & 0x40) != 0;   // BLF - limite de banda atingido
  uint32_t pll = ((uint32_t)(b[0] & 0x3F) << 8) | (uint32_t)b[1];
  stereoOut = (b[2] & 0x80) != 0;   // STEREO
  level     = (b[3] >> 4) & 0x0F;   // LEV[3:0] (0..15)
  freqOut   = pllToFreq(pll);
  return true;
}

// ======================================================================
//                        FEEDBACK PELO SERIAL
// ======================================================================
void printStatus() {
  char buf[8];
  dtostrf(currentFreq, 4, 1, buf);   // ex.: "101.9" (sem depender de printf)
  Serial.print(buf);
  Serial.print(" MHz   sinal:");
  Serial.print((int)signalLevel);
  Serial.print("   ");
  Serial.print(isStereo ? "STEREO" : "MONO");
  Serial.print((isMuted || tuningMuted) ? "   [MUDO]" : "");
  Serial.println();
}

// ======================================================================
//                    EEPROM (salvar / carregar frequencia)
// ======================================================================
void saveFrequency() {
  // guarda como inteiro (freq * 10) para evitar problemas com float na EEPROM
  int freq10 = (int)(currentFreq * 10.0f + 0.5f);
  EEPROM.put(EEPROM_FREQ_ADDR, freq10);
}

void loadFrequency() {
  int freq10;
  EEPROM.get(EEPROM_FREQ_ADDR, freq10);
  if (freq10 < FREQ_MIN10 || freq10 > FREQ_MAX10) freq10 = FREQ_DEF10;
  currentFreq = freq10 / 10.0f;
}

// ======================================================================
//                           FUNCOES DO RADIO
// ======================================================================
void radioTune(float freqMHz, bool mute) {
  if (freqMHz < FREQ_MIN10 / 10.0f) freqMHz = FREQ_MIN10 / 10.0f;
  if (freqMHz > FREQ_MAX10 / 10.0f) freqMHz = FREQ_MAX10 / 10.0f;
  currentFreq = freqMHz;
  tea5767_write(currentFreq, mute, false, true);
  saveFrequency();
}

void radioSetFrequency(float freqMHz) {
  radioTune(freqMHz, isMuted);
}

void radioToggleMute() {
  isMuted = !isMuted;
  tea5767_write(currentFreq, isMuted, false, true);
}

void radioSeek(bool up) {
  tea5767_write(currentFreq, true, true, up);   // busca em silencio
  unsigned long start = millis();
  bool ready = false, bandLimit = false, stereoOut = false;
  uint8_t level = 0;
  float freqFound = currentFreq;

  while (millis() - start < 4000) {
    delay(60);
    if (tea5767_readStatus(ready, bandLimit, stereoOut, level, freqFound)) {
      if (ready) break;
    }
  }
  currentFreq = round(freqFound * 10.0f) / 10.0f;
  if (currentFreq < FREQ_MIN10 / 10.0f) currentFreq = FREQ_MIN10 / 10.0f;
  if (currentFreq > FREQ_MAX10 / 10.0f) currentFreq = FREQ_MAX10 / 10.0f;
  tea5767_write(currentFreq, isMuted, false, up);   // devolve o som
  tuningMuted = false;
  saveFrequency();
}

void radioPollStatus() {
  bool ready = false, bandLimit = false, stereoOut = false;
  uint8_t level = 0;
  float f = currentFreq;
  if (tea5767_readStatus(ready, bandLimit, stereoOut, level, f)) {
    bool stereoChanged = (stereoOut != isStereo);
    bool levelChanged  = (abs((int)level - (int)signalLevel) >= 2);
    isStereo    = stereoOut;
    signalLevel = level;
    if (stereoChanged || levelChanged) printStatus();
  }
}

// ======================================================================
//              ENCODER ROTATIVO - QUADRATURA 4x (1 contagem por clicada)
// ======================================================================
volatile int8_t        encoderDelta     = 0;
volatile uint8_t       encoderLastState = 3;  // 11 (estado parado, pull-up)
volatile unsigned long lastEncoderIsrUs = 0;

// estado = (CLK << 1) | DT  ->  0 = 00, 1 = 01, 2 = 10, 3 = 11
// +1 = um sentido, -1 = o contrario (inverter com ENCODER_INVERT se preciso)
static const int8_t kTransitions[4][4] = {
  {  0, -1, +1,  0 },   // de 00
  { +1,  0,  0, -1 },   // de 01
  { -1,  0,  0, +1 },   // de 10
  {  0, +1, -1,  0 },   // de 11
};

void encoderISR() {
  unsigned long now = micros();
  if (now - lastEncoderIsrUs < ENCODER_ISR_DEBOUNCE_US) return;
  lastEncoderIsrUs = now;

  uint8_t state = ((uint8_t)digitalRead(ENCODER_CLK) << 1) |
                   (uint8_t)digitalRead(ENCODER_DT);
  if (state != encoderLastState) {
    encoderDelta += kTransitions[encoderLastState][state];
    encoderLastState = state;
  }
}

void handleEncoderRotation() {
  int8_t delta;
  noInterrupts();
  delta = encoderDelta;
  encoderDelta = 0;
  interrupts();

#if ENCODER_INVERT
  delta = -delta;
#endif

  // aplica o total de passos acumulados (pode ser mais de 1 se girou rapido)
  if (delta != 0) {
    radioTune(currentFreq + (float)delta * FREQ_STEP, true);  // silencia ao girar
    tuningMuted  = true;
    lastStepTime = millis();
    printStatus();
  }
}

// ======================================================================
//                  BOTAO DO ENCODER - 1 / 2 / 3 CLIQUES
// ======================================================================
uint8_t pollMultiClick(MultiClickButton &b) {
  bool reading = digitalRead(b.pin);
  unsigned long now = millis();

  if (reading != b.lastReading) {
    b.lastDebounceTime = now;
  }
  b.lastReading = reading;

  if ((now - b.lastDebounceTime) > BTN_DEBOUNCE_MS && reading != b.stableState) {
    b.stableState = reading;
    if (b.stableState == LOW) {
      if (b.clickCount == 0) b.firstClickTime = now;
      b.clickCount++;
    }
  }

  if (b.clickCount > 0 && (now - b.firstClickTime) > MULTI_CLICK_WINDOW_MS) {
    uint8_t result = b.clickCount;
    b.clickCount = 0;
    return result;
  }
  return 0;
}

void handleEncoderButton() {
  uint8_t clicks = pollMultiClick(encoderBtn);
  if (clicks == 1) {
    Serial.println(F("Buscando estacao anterior..."));
    radioSeek(false);
    printStatus();
  } else if (clicks == 2) {
    Serial.println(F("Buscando proxima estacao..."));
    radioSeek(true);
    printStatus();
  } else if (clicks >= 3) {
    radioToggleMute();
    Serial.println(isMuted ? F("Mudo: LIGADO") : F("Mudo: desligado"));
  }
}

// ======================================================================
//                                 SETUP
// ======================================================================
void setup() {
  Serial.begin(9600);
  delay(250);
  Serial.println();
  Serial.println(F("Radio FM - Arduino Uno + TEA5767 + Encoder (sem tela)"));

  // --- I2C (TEA5767) ---
  Wire.begin();

  // checa se o TEA5767 responde no bus (apenas aviso, nao trava)
  bool teaFound = false;
  for (int i = 0; i < 3 && !teaFound; i++) {
    Wire.requestFrom((int)TEA5767_ADDR, 5);
    teaFound = (Wire.available() >= 5);
    delay(20);
  }
  if (!teaFound) {
    Serial.println(F("AVISO: TEA5767 nao respondeu em 0x60. Confira SDA/SCL/VCC."));
  }

  // --- Encoder ---
  pinMode(ENCODER_CLK, INPUT_PULLUP);
  pinMode(ENCODER_DT,  INPUT_PULLUP);
  pinMode(ENCODER_SW,  INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(ENCODER_CLK), encoderISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENCODER_DT),  encoderISR, CHANGE);

  // --- Frequencia salva ---
  loadFrequency();
  radioSetFrequency(currentFreq);
  printStatus();

  Serial.println(F("Pronta. Giro = sintonia | botao: 1=anterior 2=posterior 3=mudo"));
}

// ======================================================================
//                                  LOOP
// ======================================================================
void loop() {
  handleEncoderRotation();
  handleEncoderButton();

  unsigned long now = millis();

  // som volta sozinho apos parar de girar o encoder
  if (tuningMuted && (now - lastStepTime >= TUNING_UNMUTE_DELAY_MS)) {
    tuningMuted = false;
    tea5767_write(currentFreq, isMuted, false, true);
    printStatus();
  }

  if (now - lastStatusPoll >= STATUS_POLL_INTERVAL) {
    lastStatusPoll = now;
    radioPollStatus();
  }
}
